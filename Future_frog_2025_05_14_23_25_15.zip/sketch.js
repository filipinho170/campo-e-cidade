let particles = [];

function setup() {
  createCanvas(600, 400);
  for (let i = 0; i < 100; i++) {
    particles.push(new Particle());
  }
}

function draw() {
  background(30, 100, 30);
  
  // Representação do campo com círculos verdes
  fill(50, 200, 50);
  ellipse(width / 4, height / 2, 120, 120);
  
  // Representação da cidade com quadrados cinza
  fill(180);
  rect(3 * width / 4 - 40, height / 2 - 40, 80, 80);
  
  // Partículas interagindo entre os dois espaços
  for (let particle of particles) {
    particle.update();
    particle.show();
  }
}

class Particle {
  constructor() {
    this.x = random(width);
    this.y = random(height);
    this.vx = random(-2, 2);
    this.vy = random(-2, 2);
    this.color = color(random(200, 255), random(100, 200), random(50, 150));
  }
  
  update() {
    this.x += this.vx;
    this.y += this.vy;
    
    if (this.x < 0 || this.x > width) this.vx *= -1;
    if (this.y < 0 || this.y > height) this.vy *= -1;
  }
  
  show() {
    fill(this.color);
    noStroke();
    ellipse(this.x, this.y, 8, 8);
  }
}